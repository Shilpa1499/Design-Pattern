package com.cognizant.interfaces;

public interface Packing {
	public String pack();

}
