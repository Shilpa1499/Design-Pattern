package com.cognizant.moveableimplementation;

import com.cognizant.interfaces.Movable;

public class BugattiVeyron implements Movable {
	@Override 
	public double getSpeed() 
	{ 
		return 268; 
		}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return 200000;
	}
}