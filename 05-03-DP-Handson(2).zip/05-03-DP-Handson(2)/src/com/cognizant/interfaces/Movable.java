package com.cognizant.interfaces;
public interface Movable { 
	// returns speed in MPH 
	double getSpeed();

	double getPrice(); 
	}
