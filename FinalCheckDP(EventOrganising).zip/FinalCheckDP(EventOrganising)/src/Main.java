public class Main {

	public static void main(String[] args) {

		INotificationObserver admin1 = new AdminObserver("Ram");
		INotificationObserver admin2 = new AdminObserver("Reethu");
		INotificationObserver admin3 = new AdminObserver("Anu"); 
		
		INotificationService service = new NotificationService();
		
		service.AddSubscriber(admin1);
		service.AddSubscriber(admin2);
		service.AddSubscriber(admin3);
		Event event1 = new Event("Ram events", 1000);
		Event event2 = new Event("Reethu events",700);
		Event event3 = new Event("Anu events", 600);
		
		service.NotifySubscriber(event1);
		
		service.RemoveSubscriber(admin2);
		
		service.NotifySubscriber(event2);
		
		service.NotifySubscriber(event3);
	}

}