import com.cts.interfaceimplementation.Circle;
import com.cts.interfaceimplementation.Rectangle;
import com.cts.interfaceimplementation.Square;
import com.cts.interfaces.Shape;

public class ShapeMaker {
	private Shape circle;
	private Square square;
	private Shape rectangle;
	
	public ShapeMaker() {
		circle =  (Shape) new Circle();
		rectangle = (Shape) new Rectangle();
		square =  (Square) new Square();
	}
	
	public void drawCircle() {
		circle.draw();
	}
	public void drawSquare() {
		square.draw();
	}
	public void drawRectangle() {
		rectangle.draw();
	}
	

}
