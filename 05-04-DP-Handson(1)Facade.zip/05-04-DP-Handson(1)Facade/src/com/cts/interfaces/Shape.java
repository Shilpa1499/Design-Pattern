package com.cts.interfaces;

public interface Shape {
	void draw();

}
