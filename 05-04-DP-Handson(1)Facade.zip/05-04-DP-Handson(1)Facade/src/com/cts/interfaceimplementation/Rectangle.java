package com.cts.interfaceimplementation;

import com.cts.interfaces.Shape;

public class Rectangle implements Shape {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Drawing Rectangle......");
		
	}

}
