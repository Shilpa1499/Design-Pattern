import com.cts.IUserImplementation.BasicUser;
import com.cts.IUserImplementation.PremiumUser;
import com.cts.interfaces.IUser;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChatMediator chatMediator=new ChatMediator();
		IUser user =new BasicUser(chatMediator,"ABC");
		chatMediator.AddUser(new BasicUser(chatMediator,"DEF"));
		chatMediator.AddUser(new PremiumUser(chatMediator,"XYZ"));
		chatMediator.AddUser(new PremiumUser(chatMediator,"GHI"));
		chatMediator.AddUser(new BasicUser(chatMediator,"UVW"));
		
		user.SendMessage("Hello Mediator Pattern");

	}

}
