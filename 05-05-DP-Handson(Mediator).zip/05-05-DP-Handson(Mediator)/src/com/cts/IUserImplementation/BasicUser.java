package com.cts.IUserImplementation;

import com.cts.interfaces.IChatMediator;
import com.cts.interfaces.IUser;

public class BasicUser implements IUser{

	private IChatMediator chatMediator;
	private String name;
	
	public BasicUser(IChatMediator chatMediator, String name) {
		super();
		this.chatMediator = chatMediator;
		this.name = name;
	}

	@Override
	public void RecieveMessage(String message) {
		// TODO Auto-generated method stub
		System.out.println("User name:"+name+ " message: "+message);
		
	}

	@Override
	public void SendMessage(String message) {
		// TODO Auto-generated method stub
		chatMediator.sendMessage(message);
		
	}

}
