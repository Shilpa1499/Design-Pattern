package com.cts.interfaces;

public interface IUser {
	public void RecieveMessage(String message);
	public void SendMessage(String message);

}
