package com.cts.interfaces;

public interface IChatMediator {
	 void AddUser(IUser user);
	 void sendMessage(String message);
	}
