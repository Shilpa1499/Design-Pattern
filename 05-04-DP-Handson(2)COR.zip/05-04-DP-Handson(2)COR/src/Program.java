import com.cts.ILeaveRequestHandler.Supervisor;
import com.cts.interfaces.ILeaveRequestHandler;
import com.cts.request.LeaveRequest;

public class Program {
	public static void main(String[] args) {
		LeaveRequest leaveRequest = new LeaveRequest();
		leaveRequest.setEmployee("Sita");
		leaveRequest.setLeaveDays(3);
		
		ILeaveRequestHandler leaveRequestHandler = new Supervisor();
		leaveRequestHandler.handleRequest(leaveRequest);

		System.out.println("----------------------");
		leaveRequest = new LeaveRequest();
		leaveRequest.setEmployee("Ram");
		leaveRequest.setLeaveDays(10);
		
		leaveRequestHandler = new Supervisor();
		leaveRequestHandler.handleRequest(leaveRequest);
		
		System.out.println("----------------------");
		leaveRequest = new LeaveRequest();
		leaveRequest.setEmployee("shyam");
		leaveRequest.setLeaveDays(30);
		
		leaveRequestHandler = new Supervisor();
		leaveRequestHandler.handleRequest(leaveRequest);
		
		
	}
}