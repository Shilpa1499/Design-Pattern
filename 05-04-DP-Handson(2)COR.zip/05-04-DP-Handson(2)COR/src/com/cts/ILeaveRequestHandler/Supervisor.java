package com.cts.ILeaveRequestHandler;

import com.cts.interfaces.ILeaveRequestHandler;
import com.cts.request.LeaveRequest;

public class Supervisor implements ILeaveRequestHandler {

	ILeaveRequestHandler nextHandler;
	
	@Override
	public void handleRequest(LeaveRequest leaveRequest) {

		if (leaveRequest.leaveDays <= 3) {
			System.out.println("Request Approved by Supervisor");
		}
		else {
			System.out.println("Forwarded to Project Manager");
			nextHandler = new ProjectManager();
			nextHandler.handleRequest(leaveRequest);
		}
		
	}

}