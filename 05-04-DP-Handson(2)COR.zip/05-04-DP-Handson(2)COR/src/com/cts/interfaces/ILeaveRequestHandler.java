package com.cts.interfaces;

import com.cts.request.LeaveRequest;

public interface ILeaveRequestHandler {

	public void handleRequest(LeaveRequest leaveRequest);
	
}