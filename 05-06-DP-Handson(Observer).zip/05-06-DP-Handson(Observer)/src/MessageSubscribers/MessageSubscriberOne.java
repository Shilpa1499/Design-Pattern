package MessageSubscribers;

import com.cts.interfaces.Observer;
import com.cts.message.Message;

public class MessageSubscriberOne implements Observer {

	@Override
	public void update(Message m) {
		System.out.println("MessageSubscriberOne :: " + m.getMessageContent());
	}
}