package com.cts.interfaces;

import com.cts.message.Message;

public interface Observer {
	
	void update(Message m);

}
