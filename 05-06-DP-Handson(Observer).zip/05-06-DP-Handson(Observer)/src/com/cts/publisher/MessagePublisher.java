package com.cts.publisher;

import java.util.ArrayList;
import java.util.List;

import com.cts.concrete.ConcreteSubject;
import com.cts.interfaces.Observer;
import com.cts.message.Message;
public class MessagePublisher extends ConcreteSubject {

	private List<Observer> observers = new ArrayList<Observer>();
	
	@Override
	public void attach(Observer o) {
		observers.add(o);
	}

	@Override
	public void detach(Observer o) {
		observers.remove(o);
	}

	@Override
	public void notifyUpdate(Message m) {
		for (Observer o : observers) {
			o.update(m);
		}
		System.out.println();
	}

}