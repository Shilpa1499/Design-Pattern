package com.cts.concrete;

import com.cts.State.State;
import com.cts.interfaces.Observer;
import com.cts.interfaces.Subject;

public abstract class ConcreteObserver implements Observer {

	private State observerState;

	public ConcreteObserver(Subject subject) {
		
	}

}