package com.cts.concrete;

import com.cts.State.State;
import com.cts.interfaces.Subject;
import com.cts.message.Message;

public abstract class ConcreteSubject implements Subject {

	private State state;

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
		notifyUpdate(new Message("State Changed"));
	}

}