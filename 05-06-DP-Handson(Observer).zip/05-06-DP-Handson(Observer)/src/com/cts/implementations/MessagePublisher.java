package com.cts.implementations;
import java.util.ArrayList;

import java.util.List;

import com.cts.State.State;
import com.cts.interfaces.Observer;
import com.cts.interfaces.Subject;
import com.cts.message.Message;

public class MessagePublisher implements Subject {

private List<Observer> observers = new ArrayList<>();

@Override
public void attach(Observer o) {
observers.add(o);
}

@Override
public void detach(Observer o) { 
	observers.remove(o);
	} 
@Override
public void notifyUpdate(Message m) {
	for(Observer o: observers) {
		o.update(m);
		}
	}

public void setState(State state) {
	// TODO Auto-generated method stub
	
}
}

 
