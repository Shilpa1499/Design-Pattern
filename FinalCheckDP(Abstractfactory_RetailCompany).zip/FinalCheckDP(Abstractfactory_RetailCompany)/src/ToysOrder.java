public class ToysOrder extends Order {

	public ToysOrder(String channel) {
		this.setChannel(channel);
		this.setProductType("Toy");
		processOrder();
	}

	@Override
	public void processOrder() {
		System.out.println("Processing Toy Order.");
	}
}