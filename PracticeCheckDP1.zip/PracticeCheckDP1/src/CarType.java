

public enum CarType {
	MICRO,MINI,LUXURY;

}
